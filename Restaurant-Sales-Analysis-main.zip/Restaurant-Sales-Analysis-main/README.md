Restaurant sales
This Dashboard is a collection of data from Restaurants for different KPIs like Total Restaurant, City-wise Count, Online Delivery (O = No
Delivery, 1 = Yes they have delivery), Table booking (0=No table booking,l =Yes has table booking),Votes.
Key Insights:
Res.ta.u.r-ants-APAlyse-d; 9,536 restaurants spread across top 140 cities for maximum Geographical coverage.
It allows customers to receive home delivery and book a table — which means that the availability of both options leads to greater flexibility
and hence satisfaction for the user.
Mexico City Average Rating Distribution Top cities for average restaurant ratings include Makati City and Quezon displaying the most engaged
customers.
Restaurant Location Distributions This dataset contains different addresses as location data, Dilli Haat and Sector 41 appears to have the highest
count for restaurants.
Food type and rating breakdown: The largest portion of restaurants are Subway, McDonald's and Pizza places; the highest average rated range is
among fast food chains. This suggests a bias toward established global brands.
Geographical Map: This map demonstrates the distribution of restaurants across different continents with most clusters in North America,
Europe, and Asia.
Popularity of Restaurants: Another interesting observation was the impact of online delivery on restaurants visibility and votes, making it clear
how important digital convenience is in today's restaurant industry.
